import { base44 } from './base44Client';


export const Transaction = base44.entities.Transaction;

export const Customer = base44.entities.Customer;

export const Category = base44.entities.Category;

export const Sale = base44.entities.Sale;

export const Installment = base44.entities.Installment;

export const Supplier = base44.entities.Supplier;

export const Purchase = base44.entities.Purchase;

export const PurchaseInstallment = base44.entities.PurchaseInstallment;



// auth sdk:
export const User = base44.auth;